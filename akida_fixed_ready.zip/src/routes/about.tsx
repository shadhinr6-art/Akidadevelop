import { createFileRoute, Link } from "@tanstack/react-router";
import { Target, Heart, Rocket, Globe2 } from "lucide-react";
import { Header } from "@/components/site/Header";
import { Footer } from "@/components/site/Footer";
import { Orbs } from "@/components/site/Orbs";
import { Section, SectionHeading } from "@/components/site/Section";
import { Button } from "@/components/ui/button";

export const Route = createFileRoute("/about")({
  head: () => ({
    meta: [
      { title: "About — Akida Corporation Ltd" },
      { name: "description", content: "Akida Corporation is a global IT & software studio building the products that move tomorrow's business forward. Meet the team and our mission." },
      { property: "og:title", content: "About — Akida Corporation Ltd" },
      { property: "og:description", content: "A global engineering studio obsessed with shipping software that matters." },
    ],
  }),
  component: AboutPage,
});

const values = [
  { icon: Target, t: "Outcomes over output", d: "We measure success by what your business gains, not hours billed." },
  { icon: Heart, t: "Craft we're proud of", d: "Every interaction, every line of code, considered. Quality is non-negotiable." },
  { icon: Rocket, t: "Velocity with rigor", d: "Move fast — without breaking the things that matter to your users." },
  { icon: Globe2, t: "Local roots, global craft", d: "Based in Chittagong, building to international standards for clients everywhere." },
];

function AboutPage() {
  return (
    <div className="min-h-screen bg-gradient-hero text-foreground">
      <Header />

      <section className="relative overflow-hidden pt-40 pb-20">
        <Orbs />
        <div className="absolute inset-0 grid-bg opacity-50" />
        <div className="relative mx-auto max-w-4xl px-6 text-center animate-fade-up">
          <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full glass text-xs uppercase tracking-[0.2em] text-primary mb-6">
            <span className="h-1.5 w-1.5 rounded-full bg-primary animate-glow-pulse" />
            About Akida · Established 2025
          </div>
          <h1 className="text-5xl md:text-7xl font-display font-semibold tracking-tight leading-[1.05]">
            Engineering the <span className="text-gradient">digital future</span> from Chittagong.
          </h1>
          <p className="mt-6 text-lg text-muted-foreground">
            Akida Corporation Ltd is an end-to-end IT & software solutions company helping businesses streamline operations, scale efficiently, and thrive in the digital era.
          </p>
        </div>
      </section>

      <Section className="!pt-10">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          <div className="glass-strong rounded-3xl p-10 shadow-elevated">
            <h2 className="text-3xl md:text-4xl font-display font-semibold mb-5">
              Our <span className="text-gradient">mission</span>
            </h2>
            <p className="text-muted-foreground leading-relaxed mb-4">
              To deliver end-to-end digital solutions — from strategy to execution — that empower businesses of every size to compete and win in the digital era.
            </p>
            <p className="text-muted-foreground leading-relaxed">
              We pair modern engineering with hands-on training so our clients (and the next generation of talent) are future-ready.
            </p>
          </div>
          <div className="glass-strong rounded-3xl p-10 shadow-elevated">
            <h2 className="text-3xl md:text-4xl font-display font-semibold mb-5">
              Our <span className="text-gradient">story</span>
            </h2>
            <p className="text-muted-foreground leading-relaxed mb-4">
              Founded in 2025 in Mohora, Chandgaon, Chittagong, Akida Corporation Ltd was built around a simple idea: world-class digital services should be accessible to every ambitious business — not just the giants.
            </p>
            <p className="text-muted-foreground leading-relaxed">
              From web and mobile to managed IT, marketing, and AI training, we're one trusted partner for the entire digital journey.
            </p>
          </div>
        </div>
      </Section>

      <Section>
        <SectionHeading
          eyebrow="Our values"
          title={<>What we <span className="text-gradient">stand for</span></>}
        />
        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-5">
          {values.map((v, i) => (
            <div key={v.t} className="glass rounded-2xl p-7 hover:shadow-glow-cyan transition-all animate-fade-up" style={{ animationDelay: `${i * 0.08}s` }}>
              <div className="h-12 w-12 rounded-xl bg-gradient-primary flex items-center justify-center mb-5 shadow-glow-cyan">
                <v.icon className="h-6 w-6 text-primary-foreground" />
              </div>
              <h4 className="font-display font-semibold text-lg mb-2">{v.t}</h4>
              <p className="text-sm text-muted-foreground leading-relaxed">{v.d}</p>
            </div>
          ))}
        </div>
      </Section>

      <Section>
        <div className="glass-strong rounded-3xl p-10 md:p-14 shadow-elevated relative overflow-hidden">
          <div className="absolute -top-20 -right-20 w-80 h-80 rounded-full bg-primary/20 blur-3xl" />
          <div className="relative grid grid-cols-2 md:grid-cols-4 gap-10 text-center">
            {[
              { v: "2025", l: "Established" },
              { v: "8", l: "Core services" },
              { v: "24/7", l: "Support" },
              { v: "100%", l: "Client focus" },
            ].map((s) => (
              <div key={s.l}>
                <div className="text-4xl md:text-5xl font-display font-semibold text-gradient">{s.v}</div>
                <div className="mt-2 text-sm text-muted-foreground uppercase tracking-wider">{s.l}</div>
              </div>
            ))}
          </div>
        </div>
      </Section>

      <Section>
        <div className="text-center">
          <h2 className="text-4xl md:text-5xl font-display font-semibold">
            Let's build <span className="text-gradient">together</span>.
          </h2>
          <Button asChild variant="hero" size="xl" className="mt-8">
            <Link to="/contact">Start a conversation</Link>
          </Button>
        </div>
      </Section>

      <Footer />
    </div>
  );
}
