import { createFileRoute } from "@tanstack/react-router";
import { Mail, Phone, MapPin, Send, CheckCircle2, MessageCircle } from "lucide-react";
import { useState } from "react";
import { Header } from "@/components/site/Header";
import { Footer } from "@/components/site/Footer";
import { Orbs } from "@/components/site/Orbs";
import { Button } from "@/components/ui/button";

export const Route = createFileRoute("/contact")({
  head: () => ({
    meta: [
      { title: "Contact — Akida Corporation Ltd" },
      { name: "description", content: "Tell us about your project. Akida responds within 24 hours with a clear plan, timeline, and price." },
      { property: "og:title", content: "Contact — Akida Corporation Ltd" },
      { property: "og:description", content: "Start your software project with Akida. Free 30-min discovery call." },
    ],
  }),
  component: ContactPage,
});

function ContactPage() {
  const [sent, setSent] = useState(false);

  return (
    <div className="min-h-screen bg-gradient-hero text-foreground">
      <Header />

      <section className="relative overflow-hidden pt-40 pb-16">
        <Orbs />
        <div className="absolute inset-0 grid-bg opacity-50" />
        <div className="relative mx-auto max-w-4xl px-6 text-center animate-fade-up">
          <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full glass text-xs uppercase tracking-[0.2em] text-primary mb-6">
            <span className="h-1.5 w-1.5 rounded-full bg-primary animate-glow-pulse" />
            Get in touch
          </div>
          <h1 className="text-5xl md:text-7xl font-display font-semibold tracking-tight leading-[1.05]">
            Let's build <span className="text-gradient">your next big thing.</span>
          </h1>
          <p className="mt-6 text-lg text-muted-foreground">
            Tell us about your project. We respond within 24 hours — every time.
          </p>
        </div>
      </section>

      <section className="relative mx-auto max-w-7xl px-6 pb-24">
        <div className="grid lg:grid-cols-5 gap-8">
          <div className="lg:col-span-3 glass-strong rounded-3xl p-8 md:p-10 shadow-elevated">
            {sent ? (
              <div className="flex flex-col items-center justify-center text-center py-16">
                <div className="h-16 w-16 rounded-full bg-gradient-primary flex items-center justify-center mb-5 shadow-glow-cyan">
                  <CheckCircle2 className="h-8 w-8 text-primary-foreground" />
                </div>
                <h3 className="text-2xl font-display font-semibold">Message received!</h3>
                <p className="text-muted-foreground mt-2 max-w-sm">
                  Thanks for reaching out. Our team will respond within 24 hours.
                </p>
              </div>
            ) : (
              <form
                onSubmit={(e) => { e.preventDefault(); setSent(true); }}
                className="space-y-5"
              >
                <h3 className="text-2xl font-display font-semibold mb-1">Project inquiry</h3>
                <p className="text-sm text-muted-foreground mb-6">All fields required. We keep your info private.</p>

                <div className="grid sm:grid-cols-2 gap-5">
                  <Field label="Full name"><input required className={inputCls} placeholder="Jane Doe" /></Field>
                  <Field label="Work email"><input required type="email" className={inputCls} placeholder="jane@company.com" /></Field>
                </div>
                <div className="grid sm:grid-cols-2 gap-5">
                  <Field label="Phone / WhatsApp"><input required className={inputCls} placeholder="01XXX-XXXXXX" /></Field>
                  <Field label="Service interested in">
                    <select required className={inputCls + " appearance-none"}>
                      <option value="">Select a service</option>
                      <option>Web Design & Development</option>
                      <option>Application Design & Implementation</option>
                      <option>Consulting & Automation</option>
                      <option>Managed Services</option>
                      <option>Customer Support Solutions</option>
                      <option>Graphics Design</option>
                      <option>Digital Marketing</option>
                      <option>Basic Computer & AI Training</option>
                    </select>
                  </Field>
                </div>
                <Field label="Tell us about your project">
                  <textarea required rows={5} className={inputCls + " resize-none"} placeholder="Goals, timeline, what you've tried..." />
                </Field>
                <Button type="submit" variant="hero" size="xl" className="w-full">
                  Send inquiry <Send className="ml-1 h-4 w-4" />
                </Button>
              </form>
            )}
          </div>

          <div className="lg:col-span-2 space-y-5">
            {[
              { icon: Mail, t: "Email", v: "akidacorporationbd@gmail.com", s: "Replies within 24 hours", href: "mailto:akidacorporationbd@gmail.com" },
              { icon: Phone, t: "Phone", v: "01334-209317", s: "Sat–Thu, 9am–8pm BST", href: "tel:+8801334209317" },
              { icon: MessageCircle, t: "WhatsApp", v: "01334-209317", s: "Fastest way to reach us", href: "https://wa.me/8801334209317" },
              { icon: MapPin, t: "Address", v: "Mohora, Chandgaon", s: "Chittagong, Bangladesh" },
            ].map((c, i) => {
              const Inner = (
                <div className="flex items-start gap-4">
                  <div className="h-11 w-11 shrink-0 rounded-xl bg-gradient-primary flex items-center justify-center shadow-glow-cyan">
                    <c.icon className="h-5 w-5 text-primary-foreground" />
                  </div>
                  <div className="min-w-0">
                    <div className="text-xs uppercase tracking-wider text-muted-foreground">{c.t}</div>
                    <div className="font-semibold mt-0.5 break-all">{c.v}</div>
                    <div className="text-xs text-muted-foreground mt-1">{c.s}</div>
                  </div>
                </div>
              );
              return (
                <div key={c.t} className="glass rounded-2xl p-6 hover:shadow-glow-cyan transition-all animate-fade-up" style={{ animationDelay: `${i * 0.08}s` }}>
                  {c.href ? (
                    <a href={c.href} target={c.href.startsWith("http") ? "_blank" : undefined} rel="noreferrer">
                      {Inner}
                    </a>
                  ) : Inner}
                </div>
              );
            })}
            <div className="glass-strong rounded-2xl p-6 shadow-card">
              <div className="text-sm font-semibold mb-2">Why choose Akida</div>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li>✓ End-to-end digital solutions</li>
                <li>✓ Local team, global standards</li>
                <li>✓ 24/7 support & monitoring</li>
                <li>✓ Free consultation call</li>
              </ul>
            </div>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
}

const inputCls =
  "w-full rounded-xl bg-white/5 border border-white/10 px-4 py-3 text-sm text-foreground placeholder:text-muted-foreground/60 focus:outline-none focus:border-primary/60 focus:ring-2 focus:ring-primary/20 transition-all";

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <label className="block">
      <div className="text-xs font-medium uppercase tracking-wider text-muted-foreground mb-2">{label}</div>
      {children}
    </label>
  );
}
