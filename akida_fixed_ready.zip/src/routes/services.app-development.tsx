import { createFileRoute } from "@tanstack/react-router";
import {
  Smartphone,
  Layers,
  Zap,
  ShieldCheck,
  Cloud,
  Palette,
  Code2,
  RefreshCcw,
} from "lucide-react";
import { ServicePage } from "@/components/site/ServicePage";

export const Route = createFileRoute("/services/app-development")({
  head: () => ({
    meta: [
      { title: "App Design & Implementation — Akida Corporation Ltd" },
      {
        name: "description",
        content:
          "Native and cross-platform Android & iOS mobile app development with UI/UX design, system architecture, and performance optimization.",
      },
      { property: "og:title", content: "App Design & Implementation — Akida Corporation Ltd" },
      {
        property: "og:description",
        content: "Transform ideas into functional, user-friendly mobile applications.",
      },
    ],
  }),
  component: AppDevPage,
});

function AppDevPage() {
  return (
    <ServicePage
      eyebrow="Service 02 · App Design & Implementation"
      number="02"
      icon={Smartphone}
      title={
        <>
          Mobile apps people <span className="text-gradient">actually love using</span>
        </>
      }
      tagline="Mobile experience"
      intro="From concept to App Store and Play Store, we design and build Android and iOS apps with delightful UX, rock-solid architecture, and the performance your users expect."
      heroBullets={["Android & iOS", "Native or cross-platform", "Backed by analytics"]}
      whatWeDo={[
        "Native Android (Kotlin) and iOS (Swift) app development",
        "Cross-platform apps with React Native and Flutter",
        "UI/UX design tailored to platform guidelines (Material, HIG)",
        "System architecture, API design, and backend integration",
        "Push notifications, deep linking, and offline support",
        "Performance optimization and battery / memory profiling",
        "App Store & Play Store submission and ongoing release management",
      ]}
      features={[
        {
          icon: Layers,
          title: "Architecture-first",
          desc: "Clean, modular codebases that stay maintainable as you scale.",
        },
        {
          icon: Zap,
          title: "Buttery performance",
          desc: "60fps animations, fast cold starts, lean APK/IPA sizes.",
        },
        {
          icon: ShieldCheck,
          title: "Secure data",
          desc: "Encrypted storage, secure auth, and OWASP Mobile Top 10 hardened.",
        },
        {
          icon: RefreshCcw,
          title: "Continuous delivery",
          desc: "Automated builds and over-the-air updates for fast iteration.",
        },
      ]}
      process={[
        {
          n: "01",
          t: "Define",
          d: "User research, feature mapping, and a clickable prototype before code.",
        },
        {
          n: "02",
          t: "Design",
          d: "Platform-native UI, motion, and brand-aligned visual systems.",
        },
        {
          n: "03",
          t: "Build & test",
          d: "Iterative sprints with QA on real devices and TestFlight / internal tracks.",
        },
        {
          n: "04",
          t: "Launch & evolve",
          d: "Store submission, analytics, crash monitoring, and version 2 planning.",
        },
      ]}
      packages={[
        {
          name: "MVP App",
          tagline: "Validate your idea fast.",
          price: "৳80,000",
          priceNote: "one-time",
          bullets: [
            "1 platform (Android or iOS)",
            "Up to 6 core screens",
            "Basic backend / API",
            "Push notifications",
            "Store submission",
          ],
        },
        {
          name: "Full Product",
          tagline: "Production-grade for both stores.",
          highlighted: true,
          price: "৳2,50,000",
          priceNote: "one-time",
          bullets: [
            "Android + iOS",
            "Up to 20 screens",
            "Custom backend & admin",
            "Auth, payments, deep links",
            "Analytics + crash reporting",
            "3 months post-launch support",
          ],
        },
        {
          name: "Enterprise App",
          tagline: "For teams with serious scale.",
          price: "From ৳6,00,000",
          priceNote: "scope-based",
          bullets: [
            "Multi-platform with shared core",
            "Complex integrations (ERP, CRM)",
            "Role-based access",
            "Offline-first architecture",
            "Dedicated DevOps pipeline",
            "SLA-backed support",
          ],
        },
      ]}
      industries={[
        "Healthcare",
        "Logistics",
        "E-commerce",
        "Education",
        "Fintech",
        "On-demand services",
      ]}
      techStack={[
        "Kotlin",
        "Swift",
        "React Native",
        "Flutter",
        "Firebase",
        "Node.js",
        "GraphQL",
        "Fastlane",
        "Sentry",
      ]}
      faqs={[
        {
          q: "Native or cross-platform — which do you recommend?",
          a: "Cross-platform (React Native/Flutter) suits most apps and saves cost. We recommend native when you need heavy graphics, AR, or deep OS integration.",
        },
        {
          q: "Will you submit to the App Store and Play Store?",
          a: "Yes. We handle developer accounts, store listings, screenshots, and the full submission and review process.",
        },
        {
          q: "Who owns the source code?",
          a: "You do. 100% of the source, designs, and assets are transferred to you on completion.",
        },
        {
          q: "Do you offer post-launch support?",
          a: "Yes — every package includes free support, and we offer ongoing maintenance retainers for updates and new features.",
        },
      ]}
      outcomes={[
        { v: "4.8★", l: "Avg. store rating" },
        { v: "60fps", l: "Smooth UX" },
      ]}
    />
  );
}
