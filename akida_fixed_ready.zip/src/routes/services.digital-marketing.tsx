import { createFileRoute } from "@tanstack/react-router";
import {
  Megaphone,
  Search,
  MousePointerClick,
  Mail,
  MessageSquare,
  BarChart3,
  Target,
  TrendingUp,
} from "lucide-react";
import { ServicePage } from "@/components/site/ServicePage";

export const Route = createFileRoute("/services/digital-marketing")({
  head: () => ({
    meta: [
      { title: "Digital Marketing Services — Akida Corporation Ltd" },
      {
        name: "description",
        content:
          "SEO, paid ads, social media marketing, bulk SMS & email marketing, and full campaign management to grow your business.",
      },
      { property: "og:title", content: "Digital Marketing Services — Akida Corporation Ltd" },
      {
        property: "og:description",
        content: "Result-driven marketing strategies that grow revenue.",
      },
    ],
  }),
  component: MarketingPage,
});

function MarketingPage() {
  return (
    <ServicePage
      eyebrow="Service 07 · Digital Marketing"
      number="07"
      icon={Megaphone}
      title={
        <>
          Marketing that brings <span className="text-gradient">measurable revenue</span>
        </>
      }
      tagline="Growth engine"
      intro="We blend SEO, paid ads, social, email, and SMS into a single growth system — built around your funnel and obsessed with ROAS, not vanity metrics."
      heroBullets={["ROAS-focused", "Transparent reporting", "Channel-agnostic strategy"]}
      whatWeDo={[
        "Social media marketing — Facebook, Instagram, LinkedIn, TikTok, YouTube",
        "Search engine optimization (SEO): on-page, technical, content, link building",
        "Paid advertising — Meta Ads, Google Ads, YouTube, TikTok Ads",
        "Bulk SMS marketing for promotions, alerts, and re-engagement",
        "Email marketing — campaigns, automations, lifecycle flows",
        "Landing page design and conversion rate optimization",
        "Full campaign management: strategy, creative, media buying, reporting",
        "Influencer outreach and partnership campaigns",
      ]}
      features={[
        {
          icon: Target,
          title: "Strategy first",
          desc: "We start from your funnel and unit economics — not from picking channels.",
        },
        {
          icon: BarChart3,
          title: "Real reporting",
          desc: "Live dashboards with the numbers that actually matter to your business.",
        },
        {
          icon: TrendingUp,
          title: "Compounding growth",
          desc: "SEO + content + brand investments that pay back for years, not just months.",
        },
        {
          icon: MousePointerClick,
          title: "CRO built in",
          desc: "Better ads alone won't fix a leaky funnel. We optimize the whole journey.",
        },
      ]}
      process={[
        {
          n: "01",
          t: "Audit",
          d: "Channels, funnel, creative, analytics — we benchmark where you stand.",
        },
        {
          n: "02",
          t: "Plan",
          d: "Quarterly strategy with budget allocation, KPIs, and creative themes.",
        },
        {
          n: "03",
          t: "Execute",
          d: "Launch campaigns, ship creative, and run experiments weekly.",
        },
        {
          n: "04",
          t: "Scale",
          d: "Double down on winners, kill losers, and reinvest in compounding wins.",
        },
      ]}
      packages={[
        {
          name: "SEO & Content",
          tagline: "Win organic traffic that compounds.",
          price: "৳30,000",
          priceNote: "/ month",
          bullets: [
            "Technical + on-page SEO",
            "Keyword & content strategy",
            "4–8 articles / month",
            "Link building outreach",
            "Monthly ranking & traffic reports",
          ],
        },
        {
          name: "Growth Engine",
          tagline: "Full-funnel paid + organic + email.",
          highlighted: true,
          price: "৳75,000",
          priceNote: "/ month",
          bullets: [
            "Meta + Google Ads management",
            "Social media management (3 platforms)",
            "Email marketing & automations",
            "Landing pages + CRO",
            "Weekly creative refresh",
            "Live reporting dashboard",
          ],
        },
        {
          name: "Local & SMS Boost",
          tagline: "For local businesses & promotions.",
          price: "৳18,000",
          priceNote: "/ month",
          bullets: [
            "Bulk SMS campaigns",
            "Local SEO + Google Business",
            "Social media marketing",
            "Promo creatives",
            "Lead capture & follow-up flows",
          ],
        },
      ]}
      industries={[
        "E-commerce",
        "Real estate",
        "Education",
        "Healthcare",
        "Restaurants",
        "B2B services",
      ]}
      techStack={[
        "Google Ads",
        "Meta Ads",
        "TikTok Ads",
        "Google Analytics 4",
        "Search Console",
        "Ahrefs",
        "Mailchimp",
        "Klaviyo",
        "HubSpot",
        "Bulk SMS gateways",
      ]}
      faqs={[
        {
          q: "How fast will I see results?",
          a: "Paid ads can show traction in days. SEO and content typically deliver compounding gains over 3–6 months.",
        },
        {
          q: "Who owns the ad accounts and assets?",
          a: "You do. Accounts are always set up under your business and 100% transferable.",
        },
        {
          q: "Do you handle creative — videos, copy, graphics?",
          a: "Yes. Static creatives, short-form video, copy, and landing pages are all in-scope on the Growth Engine package.",
        },
        {
          q: "What's a typical ad budget?",
          a: "We work with budgets from $300/month for local boosts up to six figures monthly. Recommendation depends on goals and CAC math.",
        },
      ]}
      outcomes={[
        { v: "5–8x", l: "Avg. ROAS" },
        { v: "+120%", l: "Avg. organic" },
      ]}
    />
  );
}
