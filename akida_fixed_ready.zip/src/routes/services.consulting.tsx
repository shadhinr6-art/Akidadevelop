import { createFileRoute } from "@tanstack/react-router";
import { Settings2, Workflow, Bot, LineChart, Lightbulb, Target, Layers, Zap } from "lucide-react";
import { ServicePage } from "@/components/site/ServicePage";

export const Route = createFileRoute("/services/consulting")({
  head: () => ({
    meta: [
      { title: "Consulting & Automation — Akida Corporation Ltd" },
      {
        name: "description",
        content:
          "Digital transformation strategy, business process automation, workflow optimization, and UX consulting by Akida Corporation Ltd.",
      },
      { property: "og:title", content: "Consulting & Automation — Akida Corporation Ltd" },
      {
        property: "og:description",
        content: "Drive digital transformation with strategic insight and smart automation.",
      },
    ],
  }),
  component: ConsultingPage,
});

function ConsultingPage() {
  return (
    <ServicePage
      eyebrow="Service 03 · Consulting & Automation"
      number="03"
      icon={Settings2}
      title={
        <>
          Smarter operations, <span className="text-gradient">less manual work</span>
        </>
      }
      tagline="Automation roadmap"
      intro="We help you find the bottlenecks, design the strategy, and deploy the automations that free your team to do higher-value work."
      heroBullets={["Process audits", "Workflow automation", "AI-powered tools"]}
      whatWeDo={[
        "Digital transformation strategy and roadmap",
        "Business process automation (BPA) with no-code & custom tools",
        "Workflow optimization across teams and departments",
        "AI integration: chatbots, document processing, predictive analytics",
        "CRM / ERP / accounting tool integrations",
        "UI/UX experience design for internal tools and customer journeys",
        "Change management and team training",
      ]}
      features={[
        {
          icon: Lightbulb,
          title: "Strategy first",
          desc: "We map outcomes to interventions — no tech for tech's sake.",
        },
        {
          icon: Workflow,
          title: "Automate everything boring",
          desc: "Reclaim hours every week with smart workflows that just run.",
        },
        {
          icon: Bot,
          title: "AI where it matters",
          desc: "Practical AI use cases that move metrics, not buzzword projects.",
        },
        {
          icon: LineChart,
          title: "Measurable impact",
          desc: "We track time saved, errors reduced, and revenue unlocked.",
        },
      ]}
      process={[
        { n: "01", t: "Audit", d: "Deep dive into current workflows, tools, and pain points." },
        {
          n: "02",
          t: "Strategy",
          d: "Prioritized roadmap with effort, impact, and ROI for each initiative.",
        },
        {
          n: "03",
          t: "Implement",
          d: "Build, integrate, and roll out automations sprint by sprint.",
        },
        {
          n: "04",
          t: "Optimize",
          d: "Measure, refine, and expand — continuous improvement built in.",
        },
      ]}
      packages={[
        {
          name: "Audit & Roadmap",
          tagline: "Clarity on where to invest first.",
          price: "৳35,000",
          priceNote: "one-time",
          bullets: [
            "Process discovery workshops",
            "Tooling & tech audit",
            "Prioritized opportunity map",
            "30/60/90 day roadmap",
            "Executive presentation",
          ],
        },
        {
          name: "Automation Sprint",
          tagline: "Ship 3–5 high-impact automations fast.",
          highlighted: true,
          price: "৳1,20,000",
          priceNote: "/ sprint",
          bullets: [
            "Everything in Audit & Roadmap",
            "Build & deploy 3–5 workflows",
            "Tool integrations (CRM, email, docs)",
            "Team training & docs",
            "1 month optimization",
          ],
        },
        {
          name: "Transformation Partner",
          tagline: "Ongoing strategic & build support.",
          price: "From ৳80,000",
          priceNote: "/ month",
          bullets: [
            "Dedicated consultant + engineer",
            "Quarterly roadmap reviews",
            "Continuous build & rollout",
            "AI integration projects",
            "Change management & enablement",
          ],
        },
      ]}
      industries={[
        "Retail",
        "Manufacturing",
        "Professional services",
        "Healthcare",
        "Logistics",
        "Education",
      ]}
      techStack={[
        "Zapier",
        "Make",
        "n8n",
        "Power Automate",
        "OpenAI",
        "HubSpot",
        "Salesforce",
        "Notion",
        "Airtable",
        "Custom APIs",
      ]}
      faqs={[
        {
          q: "Where do most clients see the biggest wins?",
          a: "Sales follow-ups, document processing, customer onboarding, and reporting are usually the fastest ROI areas.",
        },
        {
          q: "Do we need to replace our existing tools?",
          a: "Almost never. We work with what you have, fill the gaps, and only suggest replacements if the math is overwhelming.",
        },
        {
          q: "How is AI used in practice?",
          a: "Drafting emails, summarizing documents, classifying tickets, generating reports — practical, accuracy-checked use cases.",
        },
        {
          q: "How do you measure success?",
          a: "Hours saved, error rate reduction, response time, and revenue impact — defined upfront and tracked monthly.",
        },
      ]}
      outcomes={[
        { v: "20+ hrs", l: "Saved per week" },
        { v: "3x", l: "Faster ops" },
      ]}
    />
  );
}
