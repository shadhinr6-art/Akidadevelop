import { createFileRoute } from "@tanstack/react-router";
import {
  Code2,
  Gauge,
  ShieldCheck,
  Search,
  Smartphone,
  Layers,
  Cloud,
  Palette,
} from "lucide-react";
import { ServicePage } from "@/components/site/ServicePage";

export const Route = createFileRoute("/services/web-design")({
  head: () => ({
    meta: [
      { title: "Web Design & Development — Akida Corporation Ltd" },
      {
        name: "description",
        content:
          "Custom website development, e-commerce, web apps, and cloud-based systems built to scale by Akida Corporation Ltd in Chittagong, Bangladesh.",
      },
      { property: "og:title", content: "Web Design & Development — Akida Corporation Ltd" },
      {
        property: "og:description",
        content: "Powerful, scalable, high-performing websites and web applications.",
      },
    ],
  }),
  component: WebDesignPage,
});

function WebDesignPage() {
  return (
    <ServicePage
      eyebrow="Service 01 · Web Design & Development"
      number="01"
      icon={Code2}
      title={
        <>
          Websites that <span className="text-gradient">work as hard as you do</span>
        </>
      }
      tagline="High-performance website"
      intro="We design and build custom websites, e-commerce platforms, and cloud-based web applications that load fast, rank well, and convert visitors into customers."
      heroBullets={["SEO-ready architecture", "Mobile-first design", "Secure & scalable hosting"]}
      whatWeDo={[
        "Custom website design & development (marketing, corporate, portfolio)",
        "E-commerce stores with payments, shipping, and inventory",
        "Web applications, dashboards, and customer portals",
        "Cloud-based systems with auto-scaling and global CDN",
        "CMS integration (WordPress, headless CMS, or custom)",
        "Performance optimization, accessibility, and Core Web Vitals tuning",
        "Ongoing maintenance, security updates, and content support",
      ]}
      features={[
        {
          icon: Gauge,
          title: "Lightning fast",
          desc: "Sub-second loads with edge delivery, image optimization, and lean code.",
        },
        {
          icon: Search,
          title: "SEO foundations",
          desc: "Semantic HTML, schema markup, and meta optimized from day one.",
        },
        {
          icon: Smartphone,
          title: "Pixel-perfect responsive",
          desc: "Beautiful on phones, tablets, laptops, and 4K displays.",
        },
        {
          icon: ShieldCheck,
          title: "Secure by default",
          desc: "HTTPS, hardened headers, and continuous vulnerability monitoring.",
        },
      ]}
      process={[
        {
          n: "01",
          t: "Discover",
          d: "Goals, audience, competitors, and KPIs — we map the whole picture.",
        },
        {
          n: "02",
          t: "Design",
          d: "Wireframes, brand-aligned UI, and prototypes you can click through.",
        },
        {
          n: "03",
          t: "Build",
          d: "Clean, tested code shipped in weekly demos — no surprises at launch.",
        },
        {
          n: "04",
          t: "Launch & grow",
          d: "Deployment, analytics, and continuous optimization post-launch.",
        },
      ]}
      packages={[
        {
          name: "Starter Site",
          tagline: "For small businesses and personal brands.",
          price: "৳25,000",
          priceNote: "one-time",
          bullets: [
            "Up to 5 pages",
            "Mobile responsive",
            "Basic SEO setup",
            "Contact form",
            "1 month free support",
          ],
        },
        {
          name: "Business Pro",
          tagline: "For growing companies that need more horsepower.",
          highlighted: true,
          price: "৳65,000",
          priceNote: "one-time",
          bullets: [
            "Up to 15 pages",
            "Custom design system",
            "CMS / blog setup",
            "Advanced SEO + schema",
            "Speed & security hardening",
            "3 months free support",
          ],
        },
        {
          name: "E-commerce / Web App",
          tagline: "For online stores and custom platforms.",
          price: "From ৳1,50,000",
          priceNote: "scope-based",
          bullets: [
            "Unlimited pages / catalog",
            "Payments + inventory",
            "Customer accounts & dashboards",
            "API integrations",
            "Cloud hosting setup",
            "Dedicated project manager",
          ],
        },
      ]}
      industries={[
        "E-commerce",
        "Healthcare",
        "Education",
        "Fintech",
        "Real estate",
        "Hospitality",
        "Startups",
      ]}
      techStack={[
        "React",
        "Next.js",
        "TypeScript",
        "Tailwind CSS",
        "Node.js",
        "PostgreSQL",
        "WordPress",
        "Shopify",
        "AWS",
        "Cloudflare",
      ]}
      faqs={[
        {
          q: "How long does a website take?",
          a: "Starter sites typically take 2–3 weeks. Business and e-commerce projects run 4–10 weeks depending on scope.",
        },
        {
          q: "Do you provide hosting?",
          a: "Yes — we set up and manage hosting on Cloudflare, AWS, or your preferred provider with security and backups included.",
        },
        {
          q: "Will my site rank on Google?",
          a: "We build with SEO best practices, but rankings also depend on content and competition. We offer ongoing SEO as a separate service.",
        },
        {
          q: "Can you redesign my existing site?",
          a: "Absolutely. We audit what's working, preserve your SEO equity, and rebuild for speed, conversions, and modern UX.",
        },
      ]}
      outcomes={[
        { v: "<1s", l: "Page load" },
        { v: "+38%", l: "Avg. conversions" },
      ]}
    />
  );
}
