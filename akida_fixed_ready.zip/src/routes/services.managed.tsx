import { createFileRoute } from "@tanstack/react-router";
import {
  ServerCog,
  ShieldCheck,
  Activity,
  Wrench,
  Cloud,
  AlertTriangle,
  Lock,
  Clock,
} from "lucide-react";
import { ServicePage } from "@/components/site/ServicePage";

export const Route = createFileRoute("/services/managed")({
  head: () => ({
    meta: [
      { title: "Managed IT Services — Akida Corporation Ltd" },
      {
        name: "description",
        content:
          "24/7 system monitoring, proactive maintenance, cybersecurity management, and infrastructure support — your IT team, on demand.",
      },
      { property: "og:title", content: "Managed IT Services — Akida Corporation Ltd" },
      { property: "og:description", content: "Focus on growth while we manage your IT ecosystem." },
    ],
  }),
  component: ManagedPage,
});

function ManagedPage() {
  return (
    <ServicePage
      eyebrow="Service 04 · Managed Services"
      number="04"
      icon={ServerCog}
      title={
        <>
          Your IT ecosystem, <span className="text-gradient">always on</span>
        </>
      }
      tagline="Reliable IT backbone"
      intro="Stop firefighting. We monitor, maintain, secure, and optimize your servers, cloud, and endpoints around the clock — so your team can focus on growth."
      heroBullets={["24/7 monitoring", "Proactive maintenance", "Security included"]}
      whatWeDo={[
        "24/7 system & uptime monitoring with instant alerts",
        "Proactive patching, updates, and preventive maintenance",
        "Cybersecurity management: firewalls, endpoint protection, audits",
        "Cloud infrastructure management (AWS, Azure, GCP, DigitalOcean)",
        "Server, network, and database administration",
        "Backup, disaster recovery, and business continuity planning",
        "Helpdesk and end-user technical support",
        "Compliance support (ISO, GDPR-style data hygiene, PCI awareness)",
      ]}
      features={[
        {
          icon: Activity,
          title: "Always watching",
          desc: "Real-time monitoring on every critical service, with alerts before users notice.",
        },
        {
          icon: ShieldCheck,
          title: "Security baked in",
          desc: "Threat detection, patching, and hardening as a continuous discipline.",
        },
        {
          icon: Wrench,
          title: "Proactive, not reactive",
          desc: "We fix issues before they become outages — not after the panic call.",
        },
        {
          icon: Clock,
          title: "Fast SLAs",
          desc: "Defined response times so you always know what to expect when something happens.",
        },
      ]}
      process={[
        {
          n: "01",
          t: "Onboard",
          d: "Inventory your infrastructure, tools, accounts, and risk areas.",
        },
        {
          n: "02",
          t: "Stabilize",
          d: "Patch gaps, enable monitoring, and harden security baselines.",
        },
        {
          n: "03",
          t: "Operate",
          d: "24/7 monitoring, scheduled maintenance, and helpdesk support.",
        },
        {
          n: "04",
          t: "Improve",
          d: "Quarterly reviews, capacity planning, and continuous cost & risk optimization.",
        },
      ]}
      packages={[
        {
          name: "Essential",
          tagline: "Monitoring + maintenance for small teams.",
          price: "৳20,000",
          priceNote: "/ month",
          bullets: [
            "Up to 25 endpoints / 5 servers",
            "24/7 uptime monitoring",
            "Monthly patching",
            "Email helpdesk",
            "Monthly health report",
          ],
        },
        {
          name: "Business",
          tagline: "Full proactive management.",
          highlighted: true,
          price: "৳60,000",
          priceNote: "/ month",
          bullets: [
            "Up to 100 endpoints / 20 servers",
            "24/7 monitoring + alerting",
            "Endpoint protection & EDR",
            "Backups + DR drills",
            "Priority helpdesk (chat & phone)",
            "Quarterly business reviews",
          ],
        },
        {
          name: "Enterprise",
          tagline: "Mission-critical SLAs and security.",
          price: "Custom",
          priceNote: "tailored quote",
          bullets: [
            "Unlimited endpoints / servers",
            "Dedicated technical lead",
            "24/7 security operations",
            "Compliance reporting",
            "Cloud cost optimization",
            "Custom SLA",
          ],
        },
      ]}
      industries={["Healthcare", "Fintech", "E-commerce", "SaaS", "Education", "Manufacturing"]}
      techStack={[
        "AWS",
        "Azure",
        "Google Cloud",
        "Cloudflare",
        "Datadog",
        "Grafana",
        "Microsoft 365",
        "Linux",
        "Windows Server",
        "pfSense",
      ]}
      faqs={[
        {
          q: "How fast do you respond to incidents?",
          a: "Critical incidents: under 15 minutes 24/7. High: under 1 hour. Defined per package SLA.",
        },
        {
          q: "Can you work alongside our internal IT team?",
          a: "Yes — we co-manage with internal teams, taking on monitoring, after-hours, or specialty workloads as needed.",
        },
        {
          q: "Do you handle cloud bills?",
          a: "Yes. We manage cloud accounts, optimize spend, and provide transparent monthly cost reports.",
        },
        {
          q: "What about cybersecurity?",
          a: "Security is included in every package — patching, EDR, and continuous monitoring. Deep audits and penetration tests are available as add-ons.",
        },
      ]}
      outcomes={[
        { v: "99.99%", l: "Uptime SLA" },
        { v: "<15m", l: "Incident response" },
      ]}
    />
  );
}
