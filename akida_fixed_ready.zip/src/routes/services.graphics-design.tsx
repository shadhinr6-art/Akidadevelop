import { createFileRoute } from "@tanstack/react-router";
import { Palette, Layers, Sparkles, ImageIcon, Type, PenTool, Brush, Camera } from "lucide-react";
import { ServicePage } from "@/components/site/ServicePage";

export const Route = createFileRoute("/services/graphics-design")({
  head: () => ({
    meta: [
      { title: "Graphics Design Services — Akida Corporation Ltd" },
      {
        name: "description",
        content:
          "Branding, logo design, social media creatives, marketing materials, and UI/UX visuals that elevate your brand identity.",
      },
      { property: "og:title", content: "Graphics Design Services — Akida Corporation Ltd" },
      {
        property: "og:description",
        content: "Visually compelling designs that elevate your brand.",
      },
    ],
  }),
  component: GraphicsPage,
});

function GraphicsPage() {
  return (
    <ServicePage
      eyebrow="Service 06 · Graphics Design"
      number="06"
      icon={Palette}
      title={
        <>
          Visuals that make your brand <span className="text-gradient">unforgettable</span>
        </>
      }
      tagline="Brand identity"
      intro="From logos and full brand systems to social creatives and marketing collateral, our designers craft visuals that look premium and convert attention into action."
      heroBullets={[
        "Source files included",
        "Unlimited revisions in scope",
        "On-brand consistency",
      ]}
      whatWeDo={[
        "Brand identity: logo, color palette, typography, voice & guidelines",
        "Social media creatives — posts, stories, reels covers, carousels",
        "Marketing materials: flyers, brochures, business cards, banners",
        "Pitch decks, reports, and presentation templates",
        "UI/UX visuals for websites, apps, and dashboards",
        "Packaging and product label design",
        "Print and large format (signage, billboards, banners)",
      ]}
      features={[
        {
          icon: PenTool,
          title: "Distinctive style",
          desc: "We design with intent — no generic templates, no AI-stamped sameness.",
        },
        {
          icon: Layers,
          title: "System thinking",
          desc: "Every asset fits a system that scales across channels and campaigns.",
        },
        {
          icon: Sparkles,
          title: "Conversion-aware",
          desc: "Designs are evaluated on clarity and CTA strength, not just aesthetics.",
        },
        {
          icon: Brush,
          title: "Source files yours",
          desc: "You get full editable files (Figma, AI, PSD) — no vendor lock-in.",
        },
      ]}
      process={[
        { n: "01", t: "Brief", d: "Brand goals, audience, references, and must-have visual cues." },
        { n: "02", t: "Concepts", d: "2–3 directions to explore tone and visual range." },
        { n: "03", t: "Refine", d: "Pick a direction, polish, and apply across the asset list." },
        {
          n: "04",
          t: "Deliver",
          d: "Final files in every format you need + brand guidelines doc.",
        },
      ]}
      packages={[
        {
          name: "Logo Pack",
          tagline: "Just the logo, done right.",
          price: "৳5,000",
          priceNote: "one-time",
          bullets: [
            "3 initial concepts",
            "2 rounds of revisions",
            "Color & monochrome variants",
            "All file formats (SVG, PNG, PDF)",
            "Mini brand guidelines",
          ],
        },
        {
          name: "Brand Identity",
          tagline: "Full system for a launch or rebrand.",
          highlighted: true,
          price: "৳25,000",
          priceNote: "one-time",
          bullets: [
            "Logo + variants",
            "Color palette + typography",
            "Business cards, letterhead, email signature",
            "Social media starter kit (10 templates)",
            "Brand guidelines PDF",
          ],
        },
        {
          name: "Creative Retainer",
          tagline: "Ongoing design partner for your team.",
          price: "From ৳15,000",
          priceNote: "/ month",
          bullets: [
            "Monthly design hours",
            "Social creatives + ads",
            "Marketing collateral",
            "Presentations & reports",
            "Same-day turnaround on small tasks",
            "Dedicated designer",
          ],
        },
      ]}
      industries={[
        "E-commerce",
        "Restaurants",
        "Real estate",
        "Healthcare",
        "Education",
        "Startups",
      ]}
      techStack={[
        "Figma",
        "Adobe Illustrator",
        "Photoshop",
        "InDesign",
        "After Effects",
        "Canva Pro",
      ]}
      faqs={[
        {
          q: "How many revisions do I get?",
          a: "Each package includes a defined number of revision rounds. Most clients land on the perfect version in 2–3 rounds.",
        },
        {
          q: "Do I own the final designs?",
          a: "Yes — full ownership and source files are transferred on delivery.",
        },
        {
          q: "Can you match my existing brand?",
          a: "Absolutely. Send us your guidelines or examples and we'll design fully on-brand.",
        },
        {
          q: "How fast is turnaround?",
          a: "Logos: 1–2 weeks. Social creatives: 2–3 days. Retainer tasks: as fast as same-day.",
        },
      ]}
      outcomes={[
        { v: "100%", l: "On-brand" },
        { v: "2–3x", l: "Engagement lift" },
      ]}
    />
  );
}
