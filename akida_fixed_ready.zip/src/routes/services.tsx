import { createFileRoute, Link, Outlet, useLocation } from "@tanstack/react-router";
import {
  Code2,
  Smartphone,
  Settings2,
  ServerCog,
  Headphones,
  Palette,
  Megaphone,
  GraduationCap,
  ArrowRight,
  Check,
} from "lucide-react";
import { Header } from "@/components/site/Header";
import { Footer } from "@/components/site/Footer";
import { Orbs } from "@/components/site/Orbs";
import { Section } from "@/components/site/Section";
import { Button } from "@/components/ui/button";

export const Route = createFileRoute("/services")({
  head: () => ({
    meta: [
      { title: "Services — Akida Corporation Ltd" },
      {
        name: "description",
        content:
          "Web & app development, consulting, managed IT, customer support, graphics design, digital marketing, and basic computer & AI training by Akida Corporation Ltd.",
      },
      { property: "og:title", content: "Services — Akida Corporation Ltd" },
      {
        property: "og:description",
        content:
          "End-to-end digital solutions: web, mobile, cloud, AI, support, design, marketing & training.",
      },
    ],
  }),
  component: ServicesPage,
});

const services = [
  {
    n: "01",
    to: "/services/web-design",
    icon: Code2,
    title: "Web Design & Development",
    desc: "Build powerful, scalable, and high-performing digital platforms with our expert team.",
    price: "From ৳25,000",
    bullets: [
      "Custom website development",
      "E-commerce solutions",
      "Web applications",
      "Cloud-based systems",
    ],
  },
  {
    n: "02",
    to: "/services/app-development",
    icon: Smartphone,
    title: "Application Design & Implementation",
    desc: "Transform ideas into functional, user-friendly applications.",
    price: "From ৳80,000",
    bullets: [
      "Mobile app development (Android & iOS)",
      "UI/UX design",
      "System architecture & deployment",
      "Performance optimization",
    ],
  },
  {
    n: "03",
    to: "/services/consulting",
    icon: Settings2,
    title: "Consulting & Automation",
    desc: "Drive digital transformation with strategic insight and smart automation.",
    price: "From ৳35,000",
    bullets: [
      "Business process automation",
      "Digital transformation strategy",
      "Workflow optimization",
      "UI/UX experience design",
    ],
  },
  {
    n: "04",
    to: "/services/managed",
    icon: ServerCog,
    title: "Managed Services",
    desc: "Focus on growth while we manage your IT ecosystem.",
    price: "From ৳20,000/mo",
    bullets: [
      "24/7 system monitoring",
      "Proactive maintenance",
      "Cybersecurity management",
      "Technical support & infrastructure management",
    ],
  },
  {
    n: "05",
    to: "/services/customer-support",
    icon: Headphones,
    title: "Customer Support Solutions",
    desc: "Deliver exceptional customer experiences with our dedicated support services.",
    price: "From ৳35,000/mo",
    bullets: [
      "Customer Support (Voice & Chat)",
      "Lead Generation",
      "Technical Support",
      "Virtual Assistant Services",
      "IT Staff Augmentation",
    ],
  },
  {
    n: "06",
    to: "/services/graphics-design",
    icon: Palette,
    title: "Graphics Design",
    desc: "Create visually compelling designs that elevate your brand identity.",
    price: "From ৳5,000",
    bullets: [
      "Branding & logo design",
      "Social media creatives",
      "Marketing materials",
      "UI/UX visuals",
    ],
  },
  {
    n: "07",
    to: "/services/digital-marketing",
    icon: Megaphone,
    title: "Digital Marketing",
    desc: "Grow your business with result-driven marketing strategies.",
    price: "From ৳18,000/mo",
    bullets: [
      "Social media marketing",
      "Search engine optimization (SEO)",
      "Paid advertising campaigns",
      "Bulk SMS & email marketing",
      "Campaign management",
    ],
  },
  {
    n: "08",
    to: "/services/training",
    icon: GraduationCap,
    title: "Basic Computer & AI Training",
    desc: "Hands-on training programs designed for beginners — get future-ready in computers and AI.",
    price: "From ৳3,500/course",
    bullets: [
      "Basic computer literacy",
      "MS Office (Word, Excel, PowerPoint)",
      "Internet, email & online safety",
      "Hands-on AI tools (ChatGPT, Gemini, Claude)",
      "Prompt engineering for real work",
    ],
  },
] as const;

function ServicesPage() {
  const location = useLocation();

  if (location.pathname !== "/services") {
    return <Outlet />;
  }

  return (
    <div className="min-h-screen bg-gradient-hero text-foreground">
      <Header />

      <section className="relative overflow-hidden pt-40 pb-20">
        <Orbs />
        <div className="absolute inset-0 grid-bg opacity-50" />
        <div className="relative mx-auto max-w-4xl px-6 text-center animate-fade-up">
          <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full glass text-xs uppercase tracking-[0.2em] text-primary mb-6">
            <span className="h-1.5 w-1.5 rounded-full bg-primary animate-glow-pulse" />
            Our Services
          </div>
          <h1 className="text-5xl md:text-7xl font-display font-semibold tracking-tight leading-[1.05]">
            End-to-end <span className="text-gradient">digital solutions</span>
          </h1>
          <p className="mt-6 text-lg text-muted-foreground max-w-2xl mx-auto">
            From strategy to execution — we empower businesses to streamline operations, scale
            efficiently, and thrive in the digital era.
          </p>
        </div>
      </section>

      {/* TRAINING HIGHLIGHT */}
      <Section className="!py-12">
        <div className="relative glass-strong rounded-3xl p-8 md:p-12 shadow-elevated overflow-hidden">
          <div className="absolute inset-0 bg-gradient-primary opacity-10" />
          <div className="relative grid md:grid-cols-[auto,1fr,auto] gap-6 items-center">
            <div className="h-16 w-16 rounded-2xl bg-gradient-primary flex items-center justify-center shadow-glow-cyan">
              <GraduationCap className="h-8 w-8 text-primary-foreground" />
            </div>
            <div>
              <div className="text-xs uppercase tracking-[0.25em] text-primary mb-2">We Teach</div>
              <h2 className="text-2xl md:text-3xl font-display font-semibold">
                Basic Computer & <span className="text-gradient">AI Learning</span>
              </h2>
              <p className="text-muted-foreground mt-2">
                Hands-on training programs designed for beginners — get future-ready in computers
                and AI.
              </p>
            </div>
            <div className="flex flex-wrap gap-2 md:justify-end">
              <Button asChild variant="hero" size="lg">
                <Link to="/services/training">
                  Explore program <ArrowRight className="ml-1 h-4 w-4" />
                </Link>
              </Button>
              <Button asChild variant="outlineGlow" size="lg">
                <Link to="/contact">Enroll now</Link>
              </Button>
            </div>
          </div>
        </div>
      </Section>

      <Section className="!py-16">
        <div className="grid lg:grid-cols-2 gap-6">
          {services.map((s, i) => (
            <Link
              key={s.title}
              to={s.to}
              className="group relative glass rounded-2xl p-8 hover:shadow-glow-cyan transition-all animate-fade-up overflow-hidden block"
              style={{ animationDelay: `${i * 0.06}s` }}
            >
              <div className="absolute top-6 right-6 text-5xl font-display font-bold text-gradient opacity-30">
                {s.n}
              </div>
              <div className="flex items-start gap-5">
                <div className="h-14 w-14 shrink-0 rounded-2xl bg-gradient-primary flex items-center justify-center shadow-glow-cyan">
                  <s.icon className="h-7 w-7 text-primary-foreground" />
                </div>
                <div className="flex-1">
                  <h3 className="text-2xl font-display font-semibold mb-2 pr-12">{s.title}</h3>
                  <p className="text-muted-foreground leading-relaxed mb-5">{s.desc}</p>
                  <div className="mb-5 inline-flex rounded-full bg-secondary px-3 py-1.5 text-sm font-semibold text-secondary-foreground">
                    {s.price}
                  </div>
                  <ul className="grid sm:grid-cols-2 gap-2.5">
                    {s.bullets.map((b) => (
                      <li key={b} className="flex items-start gap-2 text-sm">
                        <Check className="h-4 w-4 text-primary shrink-0 mt-0.5" />
                        <span>{b}</span>
                      </li>
                    ))}
                  </ul>
                  <div className="mt-6 inline-flex items-center rounded-full border border-primary/30 px-4 py-2 text-sm font-semibold text-primary transition-all group-hover:bg-primary group-hover:text-primary-foreground group-hover:shadow-glow-cyan">
                    View details{" "}
                    <ArrowRight className="ml-1 h-3.5 w-3.5 group-hover:translate-x-1 transition-transform" />
                  </div>
                </div>
              </div>
            </Link>
          ))}
        </div>
      </Section>

      <Section>
        <div className="relative glass-strong rounded-3xl p-12 md:p-16 text-center shadow-elevated overflow-hidden">
          <div className="absolute inset-0 bg-gradient-primary opacity-10" />
          <div className="relative">
            <h2 className="text-3xl md:text-5xl font-display font-semibold">
              Not sure where to start? <span className="text-gradient">We'll guide you.</span>
            </h2>
            <p className="mt-5 text-muted-foreground max-w-xl mx-auto">
              Talk to our team — we'll recommend the right service mix for your goals and budget.
            </p>
            <Button asChild variant="hero" size="xl" className="mt-8">
              <Link to="/contact">
                Talk to us <ArrowRight className="ml-1 h-4 w-4" />
              </Link>
            </Button>
          </div>
        </div>
      </Section>

      <Footer />
    </div>
  );
}
