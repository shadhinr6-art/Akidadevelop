import { createFileRoute, Link } from "@tanstack/react-router";
import {
  ArrowRight,
  Sparkles,
  ShieldCheck,
  Zap,
  Cpu,
  Code2,
  Smartphone,
  Settings2,
  ServerCog,
  Headphones,
  Palette,
  Megaphone,
  CheckCircle2,
  Star,
  GraduationCap,
} from "lucide-react";
import heroImg from "@/assets/hero-tech.jpg";
import { Header } from "@/components/site/Header";
import { Footer } from "@/components/site/Footer";
import { Orbs } from "@/components/site/Orbs";
import { Section, SectionHeading } from "@/components/site/Section";
import { Button } from "@/components/ui/button";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Akida Corporation Ltd — IT & Software Solutions in Chittagong, Bangladesh" },
      {
        name: "description",
        content:
          "Akida Corporation Ltd delivers web & app development, cloud, AI, managed IT, customer support, design, digital marketing, and computer & AI training.",
      },
      { property: "og:title", content: "Akida Corporation Ltd — IT & Software Solutions" },
      {
        property: "og:description",
        content: "End-to-end digital solutions empowering businesses to scale in the digital era.",
      },
      { property: "og:type", content: "website" },
    ],
  }),
  component: Home,
});

const services = [
  {
    to: "/services/web-design",
    icon: Code2,
    title: "Web Design & Development",
    desc: "Custom websites, e-commerce, and cloud-based web apps built to scale.",
    color: "from-cyan-glow to-violet-glow",
  },
  {
    to: "/services/app-development",
    icon: Smartphone,
    title: "App Design & Implementation",
    desc: "Android & iOS mobile apps with thoughtful UI/UX and rock-solid performance.",
    color: "from-violet-glow to-magenta-glow",
  },
  {
    to: "/services/consulting",
    icon: Settings2,
    title: "Consulting & Automation",
    desc: "Digital transformation, process automation, and workflow optimization.",
    color: "from-cyan-glow to-magenta-glow",
  },
  {
    to: "/services/managed",
    icon: ServerCog,
    title: "Managed Services",
    desc: "24/7 monitoring, cybersecurity, and proactive IT infrastructure management.",
    color: "from-magenta-glow to-cyan-glow",
  },
  {
    to: "/services/customer-support",
    icon: Headphones,
    title: "Customer Support Solutions",
    desc: "Voice & chat support, lead generation, virtual assistants, and IT staffing.",
    color: "from-violet-glow to-cyan-glow",
  },
  {
    to: "/services/graphics-design",
    icon: Palette,
    title: "Graphics Design",
    desc: "Branding, logos, social creatives, and marketing materials that elevate you.",
    color: "from-magenta-glow to-violet-glow",
  },
  {
    to: "/services/digital-marketing",
    icon: Megaphone,
    title: "Digital Marketing",
    desc: "SEO, paid ads, social media, bulk SMS & email — campaigns that convert.",
    color: "from-cyan-glow to-magenta-glow",
  },
  {
    to: "/services/training",
    icon: GraduationCap,
    title: "Computer & AI Training",
    desc: "Hands-on basic computer and AI learning programs for future-ready students.",
    color: "from-violet-glow to-magenta-glow",
  },
] as const;

const features = [
  {
    icon: Zap,
    title: "End-to-end delivery",
    desc: "From strategy to launch — one trusted partner for every digital need.",
  },
  {
    icon: ShieldCheck,
    title: "Secure by design",
    desc: "Cybersecurity baked into every project we build and manage.",
  },
  {
    icon: Cpu,
    title: "AI-ready engineering",
    desc: "We build with modern AI tools so your business stays ahead of the curve.",
  },
  {
    icon: Sparkles,
    title: "Local team, global craft",
    desc: "Based in Chittagong, building to international standards.",
  },
];

const steps = [
  {
    n: "01",
    t: "Discover",
    d: "We listen to your goals, audience, and the metrics that matter most.",
  },
  { n: "02", t: "Design", d: "Clear strategy, architecture, and UX prototypes you can feel." },
  {
    n: "03",
    t: "Build",
    d: "Agile delivery with regular demos. Always shippable, always visible.",
  },
  { n: "04", t: "Scale", d: "Launch, monitor, optimize, and grow — together with your team." },
];

const testimonials = [
  {
    name: "Rakib Hasan",
    role: "Founder, ShopBazaar BD",
    quote:
      "Akida rebuilt our e-commerce store and our orders doubled within two months. Genuinely game-changing.",
    initials: "RH",
  },
  {
    name: "Nusrat Jahan",
    role: "Marketing Lead, GreenLeaf",
    quote:
      "Their digital marketing team gave us the highest ROAS we've ever had. Communication is top-tier.",
    initials: "NJ",
  },
  {
    name: "Tanvir Ahmed",
    role: "CEO, MediCare Plus",
    quote:
      "From mobile app to managed support, Akida handles it all. They feel like our in-house IT team.",
    initials: "TA",
  },
];

function Home() {
  return (
    <div className="min-h-screen bg-gradient-hero text-foreground">
      <Header />

      {/* HERO */}
      <section className="relative overflow-hidden pt-40 pb-32 md:pt-48 md:pb-40">
        <Orbs />
        <div className="absolute inset-0 grid-bg opacity-60" />

        <div className="relative mx-auto max-w-7xl px-6 grid lg:grid-cols-12 gap-12 items-center">
          <div className="lg:col-span-7 animate-fade-up">
            <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full glass text-xs uppercase tracking-[0.2em] text-primary mb-7">
              <span className="h-1.5 w-1.5 rounded-full bg-primary animate-glow-pulse" />
              IT & Software Solutions · Est. 2025
            </div>

            <h1 className="text-5xl md:text-6xl lg:text-7xl font-display font-semibold tracking-tight leading-[1.05]">
              Digital solutions that <span className="text-gradient">move business</span> forward.
            </h1>

            <p className="mt-7 text-lg md:text-xl text-muted-foreground max-w-2xl leading-relaxed">
              Akida Corporation Ltd delivers end-to-end digital solutions — from strategy to
              execution — empowering businesses to streamline operations, scale efficiently, and
              thrive in the digital era.
            </p>

            <div className="mt-9 flex flex-wrap gap-4">
              <Button asChild variant="hero" size="xl">
                <Link to="/contact">
                  Start Your Project <ArrowRight className="ml-1 h-4 w-4" />
                </Link>
              </Button>
              <Button asChild variant="glass" size="xl">
                <Link to="/services">Explore Services</Link>
              </Button>
            </div>

            <div className="mt-12 flex flex-wrap items-center gap-x-8 gap-y-4 text-sm text-muted-foreground">
              <div className="flex items-center gap-2">
                <CheckCircle2 className="h-4 w-4 text-primary" /> End-to-end delivery
              </div>
              <div className="flex items-center gap-2">
                <CheckCircle2 className="h-4 w-4 text-primary" /> 24/7 managed support
              </div>
              <div className="flex items-center gap-2">
                <CheckCircle2 className="h-4 w-4 text-primary" /> Based in Chittagong, BD
              </div>
            </div>
          </div>

          <div
            className="lg:col-span-5 relative animate-fade-up"
            style={{ animationDelay: "0.15s" }}
          >
            <div className="relative rounded-3xl overflow-hidden shadow-elevated border border-white/10 animate-float">
              <img
                src={heroImg}
                alt="Futuristic data network representing Akida software solutions"
                width={1536}
                height={1024}
                className="w-full h-auto"
              />
              <div className="absolute inset-0 bg-gradient-to-tr from-background/40 via-transparent to-transparent" />
            </div>
            <div
              className="absolute -bottom-6 -left-6 glass-strong rounded-2xl p-5 shadow-card hidden md:block animate-float"
              style={{ animationDelay: "1s" }}
            >
              <div className="text-3xl font-display font-semibold text-gradient">99.99%</div>
              <div className="text-xs text-muted-foreground uppercase tracking-wider mt-1">
                Uptime SLA
              </div>
            </div>
            <div
              className="absolute -top-6 -right-6 glass-strong rounded-2xl p-5 shadow-card hidden md:block animate-float"
              style={{ animationDelay: "2s" }}
            >
              <div className="text-3xl font-display font-semibold text-gradient">+38%</div>
              <div className="text-xs text-muted-foreground uppercase tracking-wider mt-1">
                Avg. conversion lift
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* TRUST BAR */}
      <section className="relative border-y border-border/40 py-10">
        <div className="mx-auto max-w-7xl px-6">
          <div className="flex items-center justify-between flex-wrap gap-8 opacity-70">
            <span className="text-xs uppercase tracking-[0.25em] text-muted-foreground">
              We work across
            </span>
            {["E-COMMERCE", "HEALTHCARE", "EDUCATION", "FINTECH", "RETAIL", "STARTUPS"].map((b) => (
              <span
                key={b}
                className="font-display font-semibold tracking-widest text-muted-foreground"
              >
                {b}
              </span>
            ))}
          </div>
        </div>
      </section>

      {/* SERVICES */}
      <Section id="services">
        <SectionHeading
          eyebrow="What we do"
          title={
            <>
              End-to-end <span className="text-gradient">technology partner</span>
            </>
          }
          subtitle="One team, every layer of the stack. We integrate seamlessly with your business and deliver outcomes — not just features."
        />
        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {services.map((s, i) => (
            <Link
              key={s.title}
              to={s.to}
              className="group relative glass rounded-2xl p-7 hover:shadow-glow-cyan transition-all duration-500 hover:-translate-y-1 animate-fade-up block cursor-pointer"
              style={{ animationDelay: `${i * 0.07}s` }}
            >
              <div
                className={`inline-flex h-12 w-12 items-center justify-center rounded-xl bg-gradient-to-br ${s.color} shadow-glow-cyan mb-5`}
              >
                <s.icon className="h-6 w-6 text-primary-foreground" />
              </div>
              <h3 className="text-xl font-display font-semibold mb-2">{s.title}</h3>
              <p className="text-sm text-muted-foreground leading-relaxed">{s.desc}</p>
              <span className="mt-5 inline-flex items-center text-sm font-medium text-primary group-hover:gap-2 transition-all">
                Learn more <ArrowRight className="ml-1 h-3.5 w-3.5 group-hover:translate-x-1 transition-transform" />
              </span>
            </Link>
          ))}
        </div>
      </Section>

      {/* WHY US */}
      <Section>
        <div className="grid lg:grid-cols-2 gap-16 items-center">
          <div>
            <SectionHeading
              align="left"
              eyebrow="Why Akida"
              title={
                <>
                  Built for <span className="text-gradient">speed, scale, and trust</span>
                </>
              }
              subtitle="We don't just write code. We become an extension of your team — obsessed with outcomes, allergic to busywork."
            />
          </div>
          <div className="grid sm:grid-cols-2 gap-5">
            {features.map((f, i) => (
              <div
                key={f.title}
                className="glass rounded-2xl p-6 hover:shadow-glow-magenta transition-all animate-fade-up"
                style={{ animationDelay: `${i * 0.08}s` }}
              >
                <div className="h-11 w-11 rounded-xl bg-gradient-primary flex items-center justify-center mb-4 shadow-glow-cyan">
                  <f.icon className="h-5 w-5 text-primary-foreground" />
                </div>
                <h4 className="font-display font-semibold mb-1.5">{f.title}</h4>
                <p className="text-sm text-muted-foreground leading-relaxed">{f.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </Section>

      {/* PROCESS */}
      <Section>
        <SectionHeading
          eyebrow="How we work"
          title={
            <>
              A proven <span className="text-gradient">4-step</span> framework
            </>
          }
          subtitle="Transparent, predictable, fast. No surprises — just steady, measurable progress every single week."
        />
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-5">
          {steps.map((s, i) => (
            <div
              key={s.n}
              className="relative glass rounded-2xl p-7 hover:shadow-glow-cyan transition-all animate-fade-up"
              style={{ animationDelay: `${i * 0.08}s` }}
            >
              <div className="text-5xl font-display font-bold text-gradient mb-3">{s.n}</div>
              <h4 className="text-xl font-display font-semibold mb-2">{s.t}</h4>
              <p className="text-sm text-muted-foreground leading-relaxed">{s.d}</p>
            </div>
          ))}
        </div>
      </Section>

      {/* STATS */}
      <Section>
        <div className="glass-strong rounded-3xl p-10 md:p-14 shadow-elevated relative overflow-hidden">
          <div className="absolute -top-20 -right-20 w-80 h-80 rounded-full bg-primary/20 blur-3xl" />
          <div className="absolute -bottom-20 -left-20 w-80 h-80 rounded-full bg-accent/20 blur-3xl" />
          <div className="relative grid grid-cols-2 md:grid-cols-4 gap-10 text-center">
            {[
              { v: "8", l: "Core services" },
              { v: "24/7", l: "Managed support" },
              { v: "100%", l: "Client focus" },
              { v: "2025", l: "Established" },
            ].map((s) => (
              <div key={s.l}>
                <div className="text-4xl md:text-5xl font-display font-semibold text-gradient">
                  {s.v}
                </div>
                <div className="mt-2 text-sm text-muted-foreground uppercase tracking-wider">
                  {s.l}
                </div>
              </div>
            ))}
          </div>
        </div>
      </Section>

      {/* TESTIMONIALS */}
      <Section>
        <SectionHeading
          eyebrow="Client love"
          title={
            <>
              What founders <span className="text-gradient">say about us</span>
            </>
          }
        />
        <div className="grid md:grid-cols-3 gap-6">
          {testimonials.map((t, i) => (
            <div
              key={t.name}
              className="glass rounded-2xl p-7 hover:shadow-glow-magenta transition-all animate-fade-up"
              style={{ animationDelay: `${i * 0.1}s` }}
            >
              <div className="flex gap-0.5 mb-4">
                {[...Array(5)].map((_, j) => (
                  <Star key={j} className="h-4 w-4 fill-primary text-primary" />
                ))}
              </div>
              <p className="text-base leading-relaxed mb-6">"{t.quote}"</p>
              <div className="flex items-center gap-3">
                <div className="h-11 w-11 rounded-full bg-gradient-primary flex items-center justify-center text-sm font-semibold text-primary-foreground">
                  {t.initials}
                </div>
                <div>
                  <div className="font-semibold text-sm">{t.name}</div>
                  <div className="text-xs text-muted-foreground">{t.role}</div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </Section>

      {/* FINAL CTA */}
      <Section>
        <div className="relative glass-strong rounded-3xl overflow-hidden p-12 md:p-20 text-center shadow-elevated">
          <div className="absolute inset-0 bg-gradient-primary opacity-10" />
          <div className="absolute -top-32 left-1/2 -translate-x-1/2 w-[600px] h-[600px] rounded-full bg-primary/20 blur-3xl" />
          <div className="relative">
            <h2 className="text-4xl md:text-6xl font-display font-semibold tracking-tight">
              Ready to build <span className="text-gradient">something legendary?</span>
            </h2>
            <p className="mt-6 text-lg text-muted-foreground max-w-2xl mx-auto">
              Tell us about your project. We'll respond within 24 hours with a clear plan, timeline,
              and price.
            </p>
            <div className="mt-9 flex flex-wrap justify-center gap-4">
              <Button asChild variant="hero" size="xl">
                <Link to="/contact">
                  Start Your Project <ArrowRight className="ml-1 h-4 w-4" />
                </Link>
              </Button>
              <Button asChild variant="outlineGlow" size="xl">
                <Link to="/services">See our work</Link>
              </Button>
            </div>
          </div>
        </div>
      </Section>

      <Footer />
    </div>
  );
}
