import { createFileRoute } from "@tanstack/react-router";
import { GraduationCap, BookOpen, Brain, Users, Award, Laptop, Bot, Target } from "lucide-react";
import { ServicePage } from "@/components/site/ServicePage";

export const Route = createFileRoute("/services/training")({
  head: () => ({
    meta: [
      { title: "Basic Computer & AI Training — Akida Corporation Ltd" },
      {
        name: "description",
        content:
          "Hands-on basic computer and AI learning programs for beginners — practical, project-based, and future-ready training in Chittagong, Bangladesh.",
      },
      { property: "og:title", content: "Basic Computer & AI Training — Akida Corporation Ltd" },
      {
        property: "og:description",
        content: "Get future-ready with hands-on computer and AI learning.",
      },
    ],
  }),
  component: TrainingPage,
});

function TrainingPage() {
  return (
    <ServicePage
      eyebrow="We Teach · Basic Computer & AI Learning"
      number="08"
      icon={GraduationCap}
      title={
        <>
          Learn computers and AI — <span className="text-gradient">the practical way</span>
        </>
      }
      tagline="Future-ready skills"
      intro="Hands-on training designed for absolute beginners. From keyboard basics to using AI tools like ChatGPT for real work — taught by working professionals, in plain language."
      heroBullets={["Beginner friendly", "Project-based", "Certificate on completion"]}
      whatWeDo={[
        "Basic computer literacy — keyboard, mouse, files, and folders",
        "Microsoft Office: Word, Excel, PowerPoint from beginner to intermediate",
        "Internet, email, and online safety fundamentals",
        "Introduction to Artificial Intelligence — what it is, how it works",
        "Hands-on with AI tools: ChatGPT, Gemini, Claude, image generators",
        "Using AI for studies, work, business, and content creation",
        "Prompt engineering basics — getting better answers from AI",
        "Online research, productivity, and workflow basics",
      ]}
      features={[
        {
          icon: Laptop,
          title: "Hands-on labs",
          desc: "Every concept practiced on a real computer — not just lectures.",
        },
        {
          icon: Brain,
          title: "Plain-language",
          desc: "We translate jargon into everyday Bangla and English. No prior tech background needed.",
        },
        {
          icon: Users,
          title: "Small batches",
          desc: "Limited seats per batch so every student gets attention.",
        },
        {
          icon: Award,
          title: "Real certificate",
          desc: "Earn an Akida Corporation Ltd certificate to add to your CV.",
        },
      ]}
      process={[
        {
          n: "01",
          t: "Enroll",
          d: "Pick a batch, complete a quick orientation, and get your study kit.",
        },
        {
          n: "02",
          t: "Learn",
          d: "Live classes + guided practice every session. No homework piling up.",
        },
        {
          n: "03",
          t: "Build",
          d: "Mini projects: a CV, a budget sheet, an AI-assisted assignment.",
        },
        {
          n: "04",
          t: "Certify",
          d: "Final assessment, certificate, and career / next-step guidance.",
        },
      ]}
      packages={[
        {
          name: "Computer Basics",
          tagline: "From zero to confident user.",
          price: "৳3,500",
          priceNote: "/ course",
          bullets: [
            "4 weeks · 2 classes/week",
            "Windows, files, internet, email",
            "MS Word + Excel basics",
            "Online safety fundamentals",
            "Certificate of completion",
          ],
        },
        {
          name: "Computer + AI",
          tagline: "Most popular — full future-ready bundle.",
          highlighted: true,
          price: "৳7,000",
          priceNote: "/ course",
          bullets: [
            "8 weeks · 2 classes/week",
            "Everything in Computer Basics",
            "Intro to AI & ChatGPT, Gemini, Claude",
            "Prompt writing for real tasks",
            "Image & content generation tools",
            "Mini project + certificate",
          ],
        },
        {
          name: "AI for Work",
          tagline: "For students, freelancers, and professionals.",
          price: "৳4,500",
          priceNote: "/ course",
          bullets: [
            "4 weeks · 2 classes/week",
            "AI workflows for content, research, study",
            "Excel + AI productivity combos",
            "Prompt engineering essentials",
            "Build your own AI assistant prompt set",
            "Certificate",
          ],
        },
      ]}
      industries={[
        "Students",
        "Job seekers",
        "Small business owners",
        "Freelancers",
        "Teachers",
        "Homemakers",
      ]}
      techStack={[
        "Windows",
        "Microsoft Office",
        "Google Workspace",
        "ChatGPT",
        "Gemini",
        "Claude",
        "Canva",
        "Image generation tools",
      ]}
      faqs={[
        {
          q: "Do I need to own a computer?",
          a: "No. Computers are provided in our classroom in Mohora, Chandgaon. Bringing your own laptop is welcome.",
        },
        {
          q: "What language are classes in?",
          a: "Bangla primarily, with English terms explained. Materials are bilingual.",
        },
        {
          q: "Are online / hybrid classes available?",
          a: "Yes — we offer in-person batches in Chittagong and live online options for those who can't attend in person.",
        },
        {
          q: "Will this help me get a job?",
          a: "Many of our graduates use these skills for office work, freelancing, or further study. We also offer career guidance after graduation.",
        },
      ]}
      outcomes={[
        { v: "8 weeks", l: "To future-ready" },
        { v: "100%", l: "Hands-on" },
      ]}
    />
  );
}
