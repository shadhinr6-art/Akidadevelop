import { createFileRoute } from "@tanstack/react-router";
import {
  Headphones,
  MessageSquare,
  Phone,
  UserCheck,
  Target,
  Users,
  Zap,
  Heart,
} from "lucide-react";
import { ServicePage } from "@/components/site/ServicePage";

export const Route = createFileRoute("/services/customer-support")({
  head: () => ({
    meta: [
      { title: "Customer Support Solutions — Akida Corporation Ltd" },
      {
        name: "description",
        content:
          "Voice & chat customer support, lead generation, technical support, virtual assistants, and IT staff augmentation.",
      },
      { property: "og:title", content: "Customer Support Solutions — Akida Corporation Ltd" },
      {
        property: "og:description",
        content: "Deliver exceptional customer experiences with our dedicated support services.",
      },
    ],
  }),
  component: SupportPage,
});

function SupportPage() {
  return (
    <ServicePage
      eyebrow="Service 05 · Customer Support Solutions"
      number="05"
      icon={Headphones}
      title={
        <>
          Customer experiences <span className="text-gradient">that earn loyalty</span>
        </>
      }
      tagline="Support team that delights"
      intro="From inbound voice and chat to lead generation and IT staff augmentation, our trained agents become an extension of your brand — friendly, fast, and focused on outcomes."
      heroBullets={["Multilingual ready", "Trained agents", "Quality monitored"]}
      whatWeDo={[
        "Customer support over voice and chat (inbound & outbound)",
        "Lead generation, qualification, and appointment setting",
        "Technical support (Tier 1 / Tier 2) and helpdesk",
        "Virtual assistant services for executives and small businesses",
        "IT staff augmentation: developers, QA, designers on demand",
        "CRM and ticketing system setup (HubSpot, Zendesk, Freshdesk)",
        "Quality assurance, scorecards, and continuous training",
      ]}
      features={[
        {
          icon: Heart,
          title: "Human-first",
          desc: "Empathetic, well-trained agents who actually solve problems.",
        },
        {
          icon: Zap,
          title: "Fast response",
          desc: "First responses in under 60 seconds on chat, under 30 on voice.",
        },
        {
          icon: Target,
          title: "Conversion focused",
          desc: "For sales workflows, agents are trained on your product, ICP, and offers.",
        },
        {
          icon: UserCheck,
          title: "Quality guaranteed",
          desc: "QA scoring, call review, and continuous coaching every week.",
        },
      ]}
      process={[
        { n: "01", t: "Scope", d: "Map volumes, channels, languages, KPIs, and tooling." },
        {
          n: "02",
          t: "Train",
          d: "Build playbooks, scripts, and product knowledge base for agents.",
        },
        { n: "03", t: "Launch", d: "Pilot with a small team, measure, refine, then scale up." },
        { n: "04", t: "Optimize", d: "Weekly QA, monthly reviews, and continuous improvement." },
      ]}
      packages={[
        {
          name: "Starter Desk",
          tagline: "1–2 dedicated agents, business hours.",
          price: "৳35,000",
          priceNote: "/ month",
          bullets: [
            "Voice or chat",
            "1 language",
            "CRM / ticketing setup",
            "Weekly QA scorecard",
            "Monthly reporting",
          ],
        },
        {
          name: "24/7 Support",
          tagline: "Round-the-clock multi-channel coverage.",
          highlighted: true,
          price: "From ৳1,50,000",
          priceNote: "/ month",
          bullets: [
            "Up to 10 dedicated agents",
            "Voice + chat + email",
            "Multi-language available",
            "Real-time dashboards",
            "Daily QA + weekly coaching",
            "Dedicated team lead",
          ],
        },
        {
          name: "Staff Augmentation",
          tagline: "Skilled tech talent on flexible terms.",
          price: "From ৳40,000",
          priceNote: "/ resource / mo",
          bullets: [
            "Developers, QA, designers, VAs",
            "Full-time or part-time",
            "Vetted & onboarded by us",
            "Direct integration with your team",
            "Replace or scale anytime",
          ],
        },
      ]}
      industries={["E-commerce", "SaaS", "Healthcare", "Education", "Real estate", "Travel"]}
      techStack={[
        "Zendesk",
        "Freshdesk",
        "HubSpot",
        "Intercom",
        "Salesforce",
        "Twilio",
        "Slack",
        "Microsoft Teams",
      ]}
      faqs={[
        {
          q: "What languages do you support?",
          a: "English and Bengali by default. Hindi, Arabic, and other languages available with notice.",
        },
        {
          q: "Can agents work in our existing CRM?",
          a: "Yes — we work in your tools (Zendesk, HubSpot, custom CRMs). We can also recommend and set one up if needed.",
        },
        {
          q: "How do you ensure quality?",
          a: "Every agent is QA-scored weekly on real conversations. Coaching plans are built into every engagement.",
        },
        {
          q: "How fast can we go live?",
          a: "A pilot team can be live in 2 weeks. Full 24/7 desks typically take 4–6 weeks to fully ramp.",
        },
      ]}
      outcomes={[
        { v: "<60s", l: "Chat response" },
        { v: "95%+", l: "CSAT target" },
      ]}
    />
  );
}
