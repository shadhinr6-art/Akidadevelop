import { Link } from "@tanstack/react-router";
import { Facebook, Linkedin, MessageCircle, Mail, Phone, MapPin } from "lucide-react";

export function Footer() {
  return (
    <footer className="relative mt-24 border-t border-border/50">
      <div className="absolute inset-x-0 top-0 h-px bg-gradient-to-r from-transparent via-primary/40 to-transparent" />
      <div className="mx-auto max-w-7xl px-6 py-16 grid gap-12 md:grid-cols-4">
        <div className="md:col-span-2">
          <div className="flex items-center gap-2.5 mb-4">
            <div className="h-9 w-9 rounded-xl bg-gradient-primary shadow-glow-cyan flex items-center justify-center font-display font-bold text-primary-foreground">
              A
            </div>
            <div>
              <div className="font-display font-semibold">Akida Corporation Ltd</div>
              <div className="text-[10px] uppercase tracking-[0.2em] text-muted-foreground">Engineering Tomorrow</div>
            </div>
          </div>
          <p className="text-sm text-muted-foreground max-w-md leading-relaxed">
            End-to-end digital solutions — web, mobile, cloud, AI, and managed services — empowering businesses across Bangladesh and beyond to scale in the digital era.
          </p>
          <div className="flex gap-3 mt-6">
            <a href="https://wa.me/8801334209317" target="_blank" rel="noreferrer" aria-label="WhatsApp" className="h-10 w-10 rounded-xl glass flex items-center justify-center hover:shadow-glow-cyan hover:text-primary transition-all">
              <MessageCircle className="h-4 w-4" />
            </a>
            <a href="mailto:akidacorporationbd@gmail.com" aria-label="Email" className="h-10 w-10 rounded-xl glass flex items-center justify-center hover:shadow-glow-cyan hover:text-primary transition-all">
              <Mail className="h-4 w-4" />
            </a>
            <a href="#" aria-label="Facebook" className="h-10 w-10 rounded-xl glass flex items-center justify-center hover:shadow-glow-cyan hover:text-primary transition-all">
              <Facebook className="h-4 w-4" />
            </a>
            <a href="#" aria-label="LinkedIn" className="h-10 w-10 rounded-xl glass flex items-center justify-center hover:shadow-glow-cyan hover:text-primary transition-all">
              <Linkedin className="h-4 w-4" />
            </a>
          </div>
        </div>

        <div>
          <h4 className="text-sm font-semibold mb-4">Company</h4>
          <ul className="space-y-2.5 text-sm text-muted-foreground">
            <li><Link to="/about" className="hover:text-foreground transition-colors">About us</Link></li>
            <li><Link to="/services" className="hover:text-foreground transition-colors">Services</Link></li>
            <li><Link to="/contact" className="hover:text-foreground transition-colors">Contact</Link></li>
          </ul>
        </div>

        <div>
          <h4 className="text-sm font-semibold mb-4">Get in touch</h4>
          <ul className="space-y-3 text-sm text-muted-foreground">
            <li className="flex items-start gap-2">
              <Mail className="h-4 w-4 mt-0.5 text-primary shrink-0" />
              <a href="mailto:akidacorporationbd@gmail.com" className="hover:text-foreground transition-colors break-all">akidacorporationbd@gmail.com</a>
            </li>
            <li className="flex items-start gap-2">
              <Phone className="h-4 w-4 mt-0.5 text-primary shrink-0" />
              <a href="tel:+8801334209317" className="hover:text-foreground transition-colors">01334-209317</a>
            </li>
            <li className="flex items-start gap-2">
              <MessageCircle className="h-4 w-4 mt-0.5 text-primary shrink-0" />
              <a href="https://wa.me/8801334209317" target="_blank" rel="noreferrer" className="hover:text-foreground transition-colors">WhatsApp: 01334-209317</a>
            </li>
            <li className="flex items-start gap-2">
              <MapPin className="h-4 w-4 mt-0.5 text-primary shrink-0" />
              <span>Mohora, Chandgaon, Chittagong</span>
            </li>
          </ul>
        </div>
      </div>
      <div className="border-t border-border/50 py-6 text-center text-xs text-muted-foreground">
        © {new Date().getFullYear()} Akida Corporation Ltd. Established 2025. All rights reserved.
      </div>
    </footer>
  );
}
