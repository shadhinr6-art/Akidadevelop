export function Orbs() {
  return (
    <div className="pointer-events-none absolute inset-0 overflow-hidden">
      <div className="orb animate-orb-drift" style={{ top: "-12%", left: "-8%", width: 520, height: 520, background: "var(--cyan-glow)" }} />
      <div className="orb animate-orb-drift" style={{ top: "20%", right: "-12%", width: 580, height: 580, background: "var(--amber-glow)", animationDelay: "-6s" }} />
      <div className="orb animate-orb-drift" style={{ bottom: "-22%", left: "18%", width: 540, height: 540, background: "var(--violet-glow)", animationDelay: "-12s" }} />
      <div className="orb animate-orb-drift" style={{ bottom: "10%", right: "20%", width: 360, height: 360, background: "var(--lime-glow)", animationDelay: "-9s" }} />
    </div>
  );
}
