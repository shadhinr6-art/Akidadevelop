import { Link } from "@tanstack/react-router";
import { Menu, X } from "lucide-react";
import { useState } from "react";
import { Button } from "@/components/ui/button";

const links = [
  { to: "/", label: "Home" },
  { to: "/services", label: "Services" },
  { to: "/about", label: "About" },
  { to: "/contact", label: "Contact" },
] as const;

export function Header() {
  const [open, setOpen] = useState(false);

  return (
    <header className="fixed top-0 left-0 right-0 z-50 px-4 pt-4">
      <nav className="mx-auto max-w-7xl glass-strong rounded-2xl px-5 py-3 flex items-center justify-between shadow-card">
        <Link to="/" className="flex items-center gap-2.5 group">
          <div className="relative h-9 w-9 rounded-xl bg-gradient-primary shadow-glow-cyan flex items-center justify-center font-display font-bold text-primary-foreground">
            A
            <div className="absolute inset-0 rounded-xl bg-gradient-primary opacity-0 group-hover:opacity-60 blur-md transition-opacity" />
          </div>
          <div className="leading-tight">
            <div className="font-display font-semibold tracking-tight">Akida</div>
            <div className="text-[10px] uppercase tracking-[0.2em] text-muted-foreground">Corporation Ltd</div>
          </div>
        </Link>

        <div className="hidden md:flex items-center gap-1">
          {links.map((l) => (
            <Link
              key={l.to}
              to={l.to}
              className="px-4 py-2 text-sm text-muted-foreground hover:text-foreground rounded-lg transition-colors"
              activeProps={{ className: "px-4 py-2 text-sm text-foreground rounded-lg bg-primary/10" }}
              activeOptions={{ exact: l.to === "/" }}
            >
              {l.label}
            </Link>
          ))}
        </div>

        <div className="hidden md:block">
          <Button asChild variant="hero" size="default">
            <Link to="/contact">Get a Quote</Link>
          </Button>
        </div>

        <button
          className="md:hidden p-2 rounded-lg glass"
          onClick={() => setOpen(!open)}
          aria-label="Toggle menu"
        >
          {open ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
        </button>
      </nav>

      {open && (
        <div className="md:hidden mx-auto max-w-7xl mt-2 glass-strong rounded-2xl p-4 flex flex-col gap-1 animate-fade-up">
          {links.map((l) => (
            <Link
              key={l.to}
              to={l.to}
              onClick={() => setOpen(false)}
              className="px-4 py-3 text-sm text-muted-foreground hover:text-foreground rounded-lg hover:bg-primary/10"
            >
              {l.label}
            </Link>
          ))}
          <Button asChild variant="hero" className="mt-2">
            <Link to="/contact" onClick={() => setOpen(false)}>Get a Quote</Link>
          </Button>
        </div>
      )}
    </header>
  );
}
