import { Link } from "@tanstack/react-router";
import { ArrowRight, Check, MessageCircle, Sparkles, type LucideIcon } from "lucide-react";
import { Header } from "@/components/site/Header";
import { Footer } from "@/components/site/Footer";
import { Orbs } from "@/components/site/Orbs";
import { Section, SectionHeading } from "@/components/site/Section";
import { Button } from "@/components/ui/button";

export type ServiceFeature = {
  icon: LucideIcon;
  title: string;
  desc: string;
};

export type ServicePackage = {
  name: string;
  tagline: string;
  bullets: string[];
  highlighted?: boolean;
  price?: string;
  priceNote?: string;
};

export type ServiceFAQ = {
  q: string;
  a: string;
};

export type ServicePageProps = {
  eyebrow: string;
  number: string;
  icon: LucideIcon;
  title: React.ReactNode;
  tagline: string;
  intro: string;
  heroBullets: string[];
  whatWeDo: string[];
  features: ServiceFeature[];
  process: { n: string; t: string; d: string }[];
  packages?: ServicePackage[];
  industries?: string[];
  techStack?: string[];
  faqs?: ServiceFAQ[];
  outcomes?: { v: string; l: string }[];
};

export function ServicePage(props: ServicePageProps) {
  const {
    eyebrow,
    number,
    icon: Icon,
    title,
    tagline,
    intro,
    heroBullets,
    whatWeDo,
    features,
    process,
    packages,
    industries,
    techStack,
    faqs,
    outcomes,
  } = props;

  return (
    <div className="min-h-screen bg-gradient-hero text-foreground">
      <Header />

      {/* HERO */}
      <section className="relative overflow-hidden pt-40 pb-20 md:pt-48 md:pb-28">
        <Orbs />
        <div className="absolute inset-0 grid-bg opacity-50" />
        <div className="relative mx-auto max-w-7xl px-6 grid lg:grid-cols-12 gap-12 items-center">
          <div className="lg:col-span-7 animate-fade-up">
            <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full glass text-xs uppercase tracking-[0.2em] text-primary mb-6">
              <span className="h-1.5 w-1.5 rounded-full bg-primary animate-glow-pulse" />
              {eyebrow}
            </div>
            <h1 className="text-5xl md:text-6xl lg:text-7xl font-display font-semibold tracking-tight leading-[1.05]">
              {title}
            </h1>
            <p className="mt-6 text-lg md:text-xl text-muted-foreground max-w-2xl leading-relaxed">
              {intro}
            </p>
            <div className="mt-8 flex flex-wrap gap-4">
              <Button asChild variant="hero" size="xl">
                <Link to="/contact">
                  Request a Quote <ArrowRight className="ml-1 h-4 w-4" />
                </Link>
              </Button>
              <Button asChild variant="glass" size="xl">
                <a href="https://wa.me/8801334209317" target="_blank" rel="noreferrer">
                  <MessageCircle className="mr-1 h-4 w-4" /> WhatsApp Us
                </a>
              </Button>
            </div>
            <div className="mt-10 flex flex-wrap gap-x-8 gap-y-3 text-sm text-muted-foreground">
              {heroBullets.map((b) => (
                <div key={b} className="flex items-center gap-2">
                  <Check className="h-4 w-4 text-primary" />
                  {b}
                </div>
              ))}
            </div>
          </div>

          <div
            className="lg:col-span-5 relative animate-fade-up"
            style={{ animationDelay: "0.15s" }}
          >
            <div className="relative glass-strong rounded-3xl p-10 shadow-elevated overflow-hidden animate-float">
              <div className="absolute inset-0 bg-gradient-primary opacity-10" />
              <div className="relative">
                <div className="text-7xl md:text-8xl font-display font-bold text-gradient opacity-90 leading-none">
                  {number}
                </div>
                <div className="mt-6 inline-flex h-20 w-20 items-center justify-center rounded-2xl bg-gradient-primary shadow-glow-cyan">
                  <Icon className="h-10 w-10 text-primary-foreground" />
                </div>
                <p className="mt-6 text-lg font-display font-semibold">{tagline}</p>
              </div>
            </div>
            {outcomes && outcomes.length >= 2 && (
              <>
                <div
                  className="absolute -bottom-6 -left-6 glass-strong rounded-2xl p-5 shadow-card hidden md:block animate-float"
                  style={{ animationDelay: "1s" }}
                >
                  <div className="text-3xl font-display font-semibold text-gradient">
                    {outcomes[0].v}
                  </div>
                  <div className="text-xs text-muted-foreground uppercase tracking-wider mt-1">
                    {outcomes[0].l}
                  </div>
                </div>
                <div
                  className="absolute -top-6 -right-6 glass-strong rounded-2xl p-5 shadow-card hidden md:block animate-float"
                  style={{ animationDelay: "2s" }}
                >
                  <div className="text-3xl font-display font-semibold text-gradient">
                    {outcomes[1].v}
                  </div>
                  <div className="text-xs text-muted-foreground uppercase tracking-wider mt-1">
                    {outcomes[1].l}
                  </div>
                </div>
              </>
            )}
          </div>
        </div>
      </section>

      {/* WHAT WE DO */}
      <Section className="!py-16">
        <div className="grid lg:grid-cols-2 gap-16 items-start">
          <div>
            <SectionHeading
              align="left"
              eyebrow="Scope"
              title={
                <>
                  What's <span className="text-gradient">included</span>
                </>
              }
              subtitle="Every engagement is tailored — but here's the core scope you can expect."
            />
          </div>
          <ul className="grid sm:grid-cols-1 gap-3">
            {whatWeDo.map((item, i) => (
              <li
                key={item}
                className="glass rounded-xl p-4 flex items-start gap-3 hover:shadow-glow-cyan transition-all animate-fade-up"
                style={{ animationDelay: `${i * 0.05}s` }}
              >
                <div className="h-6 w-6 shrink-0 rounded-md bg-gradient-primary flex items-center justify-center mt-0.5">
                  <Check className="h-3.5 w-3.5 text-primary-foreground" />
                </div>
                <span className="text-sm md:text-base">{item}</span>
              </li>
            ))}
          </ul>
        </div>
      </Section>

      {/* FEATURES / WHY */}
      <Section>
        <SectionHeading
          eyebrow="Why Akida"
          title={
            <>
              Engineered for <span className="text-gradient">real outcomes</span>
            </>
          }
          subtitle="We obsess over the details that actually move metrics — speed, security, clarity, and care."
        />
        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-5">
          {features.map((f, i) => (
            <div
              key={f.title}
              className="glass rounded-2xl p-6 hover:shadow-glow-magenta transition-all animate-fade-up"
              style={{ animationDelay: `${i * 0.07}s` }}
            >
              <div className="h-11 w-11 rounded-xl bg-gradient-primary flex items-center justify-center mb-4 shadow-glow-cyan">
                <f.icon className="h-5 w-5 text-primary-foreground" />
              </div>
              <h4 className="font-display font-semibold mb-1.5">{f.title}</h4>
              <p className="text-sm text-muted-foreground leading-relaxed">{f.desc}</p>
            </div>
          ))}
        </div>
      </Section>

      {/* PROCESS */}
      <Section>
        <SectionHeading
          eyebrow="Our process"
          title={
            <>
              From kickoff to <span className="text-gradient">launch</span>
            </>
          }
          subtitle="A predictable, transparent path with regular checkpoints so you always know where things stand."
        />
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-5">
          {process.map((s, i) => (
            <div
              key={s.n}
              className="relative glass rounded-2xl p-7 hover:shadow-glow-cyan transition-all animate-fade-up"
              style={{ animationDelay: `${i * 0.08}s` }}
            >
              <div className="text-5xl font-display font-bold text-gradient mb-3">{s.n}</div>
              <h4 className="text-xl font-display font-semibold mb-2">{s.t}</h4>
              <p className="text-sm text-muted-foreground leading-relaxed">{s.d}</p>
            </div>
          ))}
        </div>
      </Section>

      {/* PACKAGES */}
      {packages && packages.length > 0 && (
        <Section>
          <SectionHeading
            eyebrow="Engagement options"
            title={
              <>
                Choose what <span className="text-gradient">fits you</span>
              </>
            }
            subtitle="Flexible packages built around your stage, scope, and budget. Every plan includes a dedicated point of contact."
          />
          <div className="grid md:grid-cols-3 gap-6">
            {packages.map((p, i) => (
              <div
                key={p.name}
                className={`relative rounded-2xl p-7 transition-all animate-fade-up ${
                  p.highlighted
                    ? "glass-strong shadow-elevated border border-primary/40"
                    : "glass hover:shadow-glow-cyan"
                }`}
                style={{ animationDelay: `${i * 0.08}s` }}
              >
                {p.highlighted && (
                  <div className="absolute -top-3 left-1/2 -translate-x-1/2 inline-flex items-center gap-1 px-3 py-1 rounded-full bg-gradient-primary text-xs uppercase tracking-[0.18em] text-primary-foreground shadow-glow-cyan">
                    <Sparkles className="h-3 w-3" /> Most popular
                  </div>
                )}
                <h4 className="text-2xl font-display font-semibold mb-2">{p.name}</h4>
                <p className="text-sm text-muted-foreground mb-5">{p.tagline}</p>
                {p.price && (
                  <div className="mb-5 pb-5 border-b border-border/60">
                    <div className="flex items-baseline gap-1.5">
                      <span className="text-3xl md:text-4xl font-display font-bold text-gradient">
                        {p.price}
                      </span>
                      {p.priceNote && (
                        <span className="text-sm text-muted-foreground">{p.priceNote}</span>
                      )}
                    </div>
                  </div>
                )}
                <ul className="space-y-2.5">
                  {p.bullets.map((b) => (
                    <li key={b} className="flex items-start gap-2 text-sm">
                      <Check className="h-4 w-4 text-primary shrink-0 mt-0.5" />
                      <span>{b}</span>
                    </li>
                  ))}
                </ul>
                <Button
                  asChild
                  variant={p.highlighted ? "hero" : "outlineGlow"}
                  size="lg"
                  className="mt-6 w-full"
                >
                  <Link to="/contact">Get started</Link>
                </Button>
              </div>
            ))}
          </div>
        </Section>
      )}

      {/* INDUSTRIES + TECH */}
      {(industries || techStack) && (
        <Section>
          <div className="grid lg:grid-cols-2 gap-8">
            {industries && (
              <div className="glass rounded-2xl p-8">
                <div className="text-xs uppercase tracking-[0.25em] text-primary mb-3">
                  Industries we serve
                </div>
                <h3 className="text-2xl font-display font-semibold mb-5">Trusted across sectors</h3>
                <div className="flex flex-wrap gap-2">
                  {industries.map((i) => (
                    <span
                      key={i}
                      className="px-3 py-1.5 rounded-full glass text-xs uppercase tracking-wider text-muted-foreground"
                    >
                      {i}
                    </span>
                  ))}
                </div>
              </div>
            )}
            {techStack && (
              <div className="glass rounded-2xl p-8">
                <div className="text-xs uppercase tracking-[0.25em] text-primary mb-3">
                  Tools & stack
                </div>
                <h3 className="text-2xl font-display font-semibold mb-5">
                  Modern, proven technology
                </h3>
                <div className="flex flex-wrap gap-2">
                  {techStack.map((t) => (
                    <span
                      key={t}
                      className="px-3 py-1.5 rounded-full glass text-xs uppercase tracking-wider text-muted-foreground"
                    >
                      {t}
                    </span>
                  ))}
                </div>
              </div>
            )}
          </div>
        </Section>
      )}

      {/* FAQ */}
      {faqs && faqs.length > 0 && (
        <Section>
          <SectionHeading
            eyebrow="FAQ"
            title={
              <>
                Questions, <span className="text-gradient">answered</span>
              </>
            }
          />
          <div className="grid md:grid-cols-2 gap-5 max-w-5xl mx-auto">
            {faqs.map((f, i) => (
              <div
                key={f.q}
                className="glass rounded-2xl p-6 animate-fade-up"
                style={{ animationDelay: `${i * 0.05}s` }}
              >
                <h4 className="font-display font-semibold mb-2">{f.q}</h4>
                <p className="text-sm text-muted-foreground leading-relaxed">{f.a}</p>
              </div>
            ))}
          </div>
        </Section>
      )}

      {/* CTA */}
      <Section>
        <div className="relative glass-strong rounded-3xl p-12 md:p-16 text-center shadow-elevated overflow-hidden">
          <div className="absolute inset-0 bg-gradient-primary opacity-10" />
          <div className="absolute -top-32 left-1/2 -translate-x-1/2 w-[500px] h-[500px] rounded-full bg-primary/20 blur-3xl" />
          <div className="relative">
            <h2 className="text-3xl md:text-5xl font-display font-semibold">
              Let's build your <span className="text-gradient">{tagline.toLowerCase()}</span>
            </h2>
            <p className="mt-5 text-muted-foreground max-w-xl mx-auto">
              Share your goals — we'll respond within 24 hours with a clear plan, timeline, and
              price.
            </p>
            <div className="mt-8 flex flex-wrap justify-center gap-4">
              <Button asChild variant="hero" size="xl">
                <Link to="/contact">
                  Request a Quote <ArrowRight className="ml-1 h-4 w-4" />
                </Link>
              </Button>
              <Button asChild variant="outlineGlow" size="xl">
                <Link to="/services">All services</Link>
              </Button>
            </div>
          </div>
        </div>
      </Section>

      <Footer />
    </div>
  );
}
